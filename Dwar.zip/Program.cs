﻿
using dwarfs;
using System;
using System.Diagnostics.Metrics;
using System.Net;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;
//regex, class,
//string[] input = Console.ReadLine().Split().ToArray();
//using dwarfs_classes();

// add cars, cups, rings
// comment the code , make the instance  and add  
//Console.WriteLine("......................................1");
//public class Dwar1
//{
//    public string Name { get; }
//    public string Hatcolor { get; }
//    public int Phyzics { get; }
//    public string Car { get; }
//    public string Cup { get; }
//    public string Ring { get; }



//}
//creating class about Steve's instruments with tool properties
/// <summary>
/// //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/// Speaking Protocol for Alex and Jordan

//1.Respectful Address:

//Always address each other by name at the beginning of a conversation or when trying to get the other's attention.
//    Use polite forms of address (e.g., "Could you," "Would you mind if").

//2. Active Listening:

//    When one person is speaking, the other should give their full attention, without interrupting.
//    Show active engagement by nodding or using verbal affirmations like "I see," "Understood," or "Go on."

//3. Clarification and Questions:

//    If something is not clear, politely ask for clarification: "Could you elaborate on that?" or "I didn't quite catch that last part, could you repeat?"
//    Encourage questions at any point to ensure both parties understand each other fully.
//4. Turn-Taking:

//    Allow each other to finish speaking before responding.
//    If an interruption is necessary, do so politely by saying, "Excuse me," or "Sorry for interrupting, but..."
//5. Constructive Feedback:

//    Offer feedback in a constructive manner, focusing on the issue, not the person.
//    Start with positive feedback before moving to areas of improvement: "I really liked your idea about X, and I wonder if we could also consider Y..."
//6.Express Appreciation:

//Thank each other for contributions, ideas, and time after discussions: "Thanks for sharing your thoughts," or "I appreciate your input on this."
//////////////////////////////////////////
//7. Confidentiality and Trust:

//    Keep personal or sensitive information discussed in confidence.
//    Build trust by being reliable and following through on promises or tasks agreed upon.

//8. Conflict Resolution:

//    Address disagreements or conflicts directly and respectfully, aiming for a solution that benefits both parties.
//    Use "I" statements to express feelings without blaming, such as "I feel concerned about X because..."

//9. Ending Conversations:

//    Conclude discussions with a summary of key points or action items.
//    Always end on a positive note, expressing forward-looking optimism: "I'm looking forward to seeing how this turns out."

//10.Availability and Scheduling:
//-Be clear about availability for discussions and respect each other's time.
//- Schedule conversations in advance when possible, and notify the other person promptly if there needs to be a change.
/// </summary>
public class Speaking_Protocol_fo_Jonii_and_Chester
{ 
    public string Begin_coversation { get; set; }
    public string Using_Polite_Forms_Of_Address { get; set; }
    public string Full_Attention_Without_Interrupting { get; set; }
    public string politely_Ask_For_Clarification { get; set; }
    public string Allow_Each_Other_To_Finish_Speaking_Before_Responding{ get; set; }
    public string Necessary_Interruption { get; set; }
    //Thank each other for contributions, ideas, and time after discussions:

}

public class Instrumnets
{ 
    public string Pickaxe { get; set; }
    public string Axe { get; set; }
    public string Shovel { get; set; }

    public string CraftingTable { get; set; }    
}
//try making different tools with different ore elements
// make checks if you can get ore elements with diff tools
//creating class about MinecraftOres  with different Ores properties
// previem of minecraft tool crafting check "if (iron >= Pickaxe)", this means if we can make an iron Pickaxe
public class MinecraftOres
{
    public string Stone { get; set; } // can 
    public string IronOre { get; set; } // can 
    public string DiamondOre { get; set; } // can
    public string EmeraldOre { get; set; } // can not
    public string GoldOre { get; set; } //can
    public string RedStoneOre { get; set; } //Can not
    public string CopperOre { get; set; } //Can not
}

//creating class about Dwar  with different  properties, like "name, "Car" and etc
public class Dwar<T1, T2, T3, T4, T5, T6>
{
    public T1 Name { get; set; }
    public T2 HatColor { get; set; }
    public T3 Phyzics { get; set; }
    public T4 Car { get; set; }
    public T5 Cup { get; set; }
    public T6 Ring { get; set; }
    //public Instrumnets Instruments { get; set; }
    //public MinecraftOres BagOfOres { get; set; }

    //private T7 gh;

    //public T7 Gh
    //{ 
    //    get { return gh; }
    //    set { gh = value; }
    //}

}
public class Threeuple<T1, T2, T3>
{
    public T1 Item1 { get; set; }
    public T2 Item2 { get; set; }
    public T3 Item3 { get; set; }
}

////MinecraftOres minecraftOres = new MinecraftOres();
namespace dwarfs
{
    internal class Program
    {
        
            

        static void Main(string[] args)
        {
            Instrumnets steveInstrumnets = new Instrumnets();
            steveInstrumnets.Pickaxe = "Pickaxe";
            steveInstrumnets.Axe = "Axe";
            steveInstrumnets.Shovel = "Shovel";
            steveInstrumnets.CraftingTable = "CraftingTable";

            MinecraftOres minecraftmaterials = new MinecraftOres();
            minecraftmaterials.Stone = "Stone";
            minecraftmaterials.IronOre = "IronOre";
            minecraftmaterials.DiamondOre = "DiamondOre";
            minecraftmaterials.EmeraldOre = "EmeraldOre";
            minecraftmaterials.GoldOre = "GoldOre";//////////////// last edit
            minecraftmaterials.DiamondOre = "DiamondOre";
            //minecraftOres.DiamondOre = "";
            string[] options = ["chop a tree", "get an ore"];
            Console.WriteLine("please select the instrument and the material....");
            string[] instrcommand = Console.ReadLine().Split(" ").ToArray();
            string instrcommand1 = instrcommand[0] + instrcommand[1];
            if (instrcommand[0] == minecraftmaterials.Stone && instrcommand[1] == steveInstrumnets.Pickaxe)
            {
                Console.WriteLine("Bravo .. .you succesfully made your first pickaxe");
                Console.WriteLine("Now choose what are you going to do with it");
                for(int i = 0; i < instrcommand.Length; i++)
                {
                    Console.WriteLine(options[i]);
                }
                string choise = Console.ReadLine();
                if (options[1] == choise)
                {
                    Console.WriteLine("alright let;s get some ore. What ore do u want?");
                    string oreToChoose = Console.ReadLine();
                    if(oreToChoose == minecraftmaterials.IronOre )
                    {
                        Console.WriteLine("let's get some iron ore");
                        string ddf = Console.ReadLine();
                        if (instrcommand1 == minecraftmaterials.IronOre)
                        {
                            Console.WriteLine($"{instrcommand}  --->>>>> {minecraftmaterials.IronOre}");
                        }
                    }
                }
            }

            string className = Console.ReadLine();
            List<string> dwarfj = new List<string>();
            List<string> dwarfc = new List<string>();
            ///////////////////////////

            

            


            Dwar<string, string, string, string, string, string> Jonii = new Dwar<string, string, string, string, string, string>();
            Jonii.Name = "jonii";
            Jonii.HatColor = "red";
            Jonii.Phyzics = "999";
            int.Parse(Jonii.Phyzics);
            Jonii.Car = "dodge charger 1969";
            Jonii.Cup = "TeaCup";
            Jonii.Ring = "SkullRing";
            //Jonii.BagOfOres.CopperOre = "1000";

            Dwar<string, string, string, string, string, string> Chester = new Dwar<string, string, string, string, string, string>();
            Chester.Name = "Chester";
            Chester.HatColor = "orange";
            Chester.Phyzics = "99999";
            int.Parse(Chester.Phyzics);
            Chester.Car = "Toyota";
            Chester.Cup = "CoffeCup";
            Chester.Ring = "RoseRing";

            if (Chester.Name == Jonii.Name)
            {
                Console.WriteLine("Sorry the check failed");
            }
            else
            {
                Console.WriteLine("Check num 1.... passed");
                Threeuple<string, string, string> info = new Threeuple<string, string, string>();
                string[] inpu = Console.ReadLine().Split(" ").ToArray();
                string fullNmae = $"{inpu[0]} {inpu[1]}";
                info.Item1 = fullNmae;
                info.Item2 = inpu[2];
                info.Item3 = inpu[3];

                Threeuple<string, int, string> stringInt = new Threeuple<string, int, string>();
                string[] inpu1 = Console.ReadLine().Split(" ").ToArray();
                stringInt.Item1 = inpu1[0];
                stringInt.Item2 = int.Parse(inpu1[1]);
                stringInt.Item3 = inpu1[2];

                Threeuple<string, double, string> IntDouble = new Threeuple<string, double, string>();
                string[] inpu2 = Console.ReadLine().Split(" ").ToArray();
                IntDouble.Item1 = inpu2[0];
                IntDouble.Item2 = double.Parse(inpu2[1]);
                IntDouble.Item3 = inpu2[2];

                Console.WriteLine($"{info.Item1} -> {info.Item2} -> {info.Item3}"); //GIVES ERROR FIX PLEASE
                Console.WriteLine($"{stringInt.Item1} -> {stringInt.Item2} -> {stringInt.Item3}");
                Console.WriteLine($"{IntDouble.Item1} -> {IntDouble.Item2} -> {IntDouble.Item3}");
            }


            if (Jonii.Name.Contains("jonii"))
            {
                Console.WriteLine("OK you passed the first check but are u going to pass the 2-cond one?");

            }
            else
            {
                Console.WriteLine("failed 1. You won't get to the nect check if you faill this one");

            }
     
            if (Jonii.Name == Chester.Name)
            {
                Console.WriteLine("Name check passed, adding the names in the dwarfs List. ");
                dwarfj.Add(Jonii.Name);
                dwarfc.Add(Chester.Name);
                Console.WriteLine("Adding NAME data finished!");
            }
            else
            {
                Console.WriteLine("Name check failed, adding the names in the dwarfs List. ");
                dwarfj.Add(Jonii.Name);
                dwarfc.Add(Chester.Name);
                Console.WriteLine("Adding NAME data finished!");
                if (Jonii.HatColor != Chester.HatColor)
                {
                    Console.WriteLine("Check for HaTCOLORRS PASSED, THE CODE WILL  add the names in the dwarfs List.");
                    dwarfj.Add(Jonii.HatColor);
                    dwarfc.Add(Chester.HatColor);
                    Console.WriteLine("Adding Hatcolor data finished!");
                    if (int.Parse(Jonii.Phyzics) < int.Parse(Chester.Phyzics))
                    {

                        Console.WriteLine("Physics check passed, adding the physics in the list");
                        dwarfj.Add(Jonii.Phyzics);
                        dwarfc.Add(Chester.Phyzics);
                        Console.WriteLine("Adding physics data finished!");
                        if (Jonii.Car == Chester.Car)
                        {
                            Console.WriteLine("Car check passed, adding car data in the list");
                            dwarfj.Add(Jonii.Car);
                            dwarfc.Add(Chester.Car);
                            Console.WriteLine("Adding car data finished!");
                        }
                        else
                        {
                            Console.WriteLine("Car check failed, adding car data in the list");
                            dwarfj.Add(Jonii.Car);
                            dwarfc.Add(Chester.Car);//////////////////////////////////////////////////////////////////////
                            Console.WriteLine("Adding car data finished!");
                            if (Jonii.Cup != Chester.Cup)
                            {
                                Console.WriteLine("Cup check passed, adding cup data in the list");
                                dwarfj.Add(Jonii.Cup);
                                dwarfc.Add(Chester.Cup);//////////////////////////////////////////////////////////////////////
                                Console.WriteLine("Adding cup data finished!");
                                if (Jonii.Ring != Chester.Ring)
                                {
                                    Console.WriteLine("Ring check passed, adding cup data in the list");
                                    dwarfj.Add(Jonii.Ring);
                                    dwarfc.Add(Chester.Ring);//////////////////////////////////////////////////////////////////////
                                    Console.WriteLine("Adding Ring data finished!");
                                    //if ()
                                    //{
                                    //MAKE FAVOIRATE PRASES FOR EACH OF THE OBJECTS(HEROES), THEN CHECK IF THE FIRST WORD IN  BOTH SENTENCES IS THE SAME
                                    //}
                                    ////////////
                                    Console.WriteLine("Beginning of the middle for cycles");
                                    for (int f = 0; f < dwarfj.Count; f++)
                                    {
                                        Console.WriteLine(dwarfj[f]);
                                        for (int q = 0; q < dwarfj.Count; q++)
                                        {
                                            Console.WriteLine(dwarfc[q]);
                                        }
                                    }
                                    Console.WriteLine("End of the middle for cycles");
                                    //if()
                                    //{

                                    //}
                                    //////////////////////////////
                                }
                                else
                                {
                                    Console.WriteLine("Ring check failed, adding cup data in the list");
                                    dwarfj.Add(Jonii.Ring);
                                    dwarfc.Add(Chester.Ring);//////////////////////////////////////////////////////////////////////
                                    Console.WriteLine("Adding Ring data finished!");
                                }
                            }
                            else
                            {
                                Console.WriteLine("Cup check failed, adding cup data in the list");
                                dwarfj.Add(Jonii.Cup);
                                dwarfc.Add(Chester.Cup);//////////////////////////////////////////////////////////////////////
                                Console.WriteLine("Adding cup data finished!");
                            }
                        }
                    }
                    else
                    {
                        Console.WriteLine("Physics check failed, adding the physics data in the list");
                        dwarfj.Add(Jonii.Phyzics);
                        dwarfc.Add(Chester.Phyzics);
                        Console.WriteLine("Adding physics data finished!");
                    }
                }
                else
                {
                    Console.WriteLine("The HaTCOLORRS check failed. Please try again later.......");
                    Console.WriteLine("Adding the hatcolors in the list");
                    dwarfj.Add(Jonii.HatColor);
                    dwarfc.Add(Chester.HatColor);
                }
            }
            Console.WriteLine("THANKS FOR TESTING");




            Console.WriteLine("Here is the Final result. The lists u built!!!---->");
            Console.WriteLine("Jonny's list---->:");
            for (int i = 0; i < dwarfj.Count; i++)
            {
                Console.WriteLine(dwarfj[i]);
            }
            Console.WriteLine("Chester's list---->:");
            for (int c = 0; c < dwarfc.Count; c++)
            {
                Console.WriteLine(dwarfc[c]);
            }


            
        }
    }
}



