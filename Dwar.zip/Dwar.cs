﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dwarfs
{
    public class Dwar
    {
        public string Name { get; }
        public string Hatcolor { get; }
        public int Phyzics { get; }
        public string Car { get; }
        public string Cup { get; }
        public string Ring { get; }

        public Dwar(string name, string hatcolor, int fyzics, string car, string cup, string ring)
        {
            Name = name;
            Hatcolor = hatcolor;
            Phyzics = fyzics;
            Car = car;
            Cup = cup;
            Ring = ring;

        }
    }
}
